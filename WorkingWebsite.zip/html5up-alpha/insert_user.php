<!DOCTYPE HTML>
<!--
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
 <?php
            session_start();
        
            if($_SESSION['login'] != "OK")
            {
                header('Location: login.php');
                exit();
            }
        
            $new_user = $_POST["new_username"];
            $new_pass = $_POST["new_password"];
            $conn = @mysql_connect ("198.91.81.4", "tmorgan1_admin", "multiuserone")
            or die ("Sorry - unable to connect to MySQL database.");
        
            $rs = @mysql_select_db ("tmorgan1_admin", $conn) or die ("error");
            $sql = "INSERT INTO user (username, password) VALUES ('$new_user', '$new_pass')";
            mysql_query($sql,$conn) or die ("User creation failed.");
            echo "<p>User created successfully.</p>";
            echo "<p>Return to <a href='protected.php'>application</a> or <a
            href='login.php'>log out</a></p>";
?>